package com.emp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.emp.bean.CustomerBean;
import com.emp.bean.MobileBean;
import com.emp.dao.CustomerDao;
import com.emp.dao.CustomerDaoImpl;
import com.emp.exception.MobileException;
public class CustomerServiceImpl implements CustomerService
{
	private CustomerDao employeedao = new CustomerDaoImpl();

	@Override
	public int addCustomer(CustomerBean bean) throws MobileException 
	{
		int id= employeedao.addCustomer(bean);
		return id;
	}

	@Override
	public int deleteMob(int deleteId) throws MobileException 
	{
		int id = employeedao.deleteMob(deleteId);
		return id;
	}

	@Override
	public List<MobileBean> viewAllMob() throws MobileException 
	{
		CustomerDaoImpl employeeDao = new CustomerDaoImpl();
		List<MobileBean> employeeList = null;

		employeeList = employeeDao.viewAllMob();
		return employeeList;
	}

	@Override
	public  MobileBean viewMobById(int viewId) throws MobileException 
	{
		MobileBean bean = new MobileBean();
		bean = employeedao.viewMobById(viewId);
		return bean;
	}

	@Override
	public List<MobileBean> searchByRange(int min, int max)
			throws MobileException
		{
		CustomerDaoImpl employeeDao = new CustomerDaoImpl();
		List<MobileBean> employeeList = null;

		employeeList = employeeDao.searchByRange(min,max);
		return employeeList;
	}
	
	@Override
	public boolean validateName(String name) throws MobileException 
	{
		Pattern pattern =Pattern.compile("[A-Z][A-Za-z]{3,14}");
		Matcher matcher= pattern.matcher(name);
		return matcher.matches();
	}

	@Override
	public boolean validatePhone(String phone) throws MobileException 
	{
		Pattern pattern =Pattern.compile("[1-9][0-9]{9}");
		Matcher matcher= pattern.matcher(String.valueOf(phone));
		return matcher.matches();
		
	}

	@Override
	public boolean validateEmail(String email) throws MobileException 
	{
		Pattern pattern =Pattern.compile("\\b[\\w.%-]+@[-.\\w]+\\.[A-Za-z]{2,4}\\b");
		Matcher matcher= pattern.matcher(email);
		return matcher.matches();
	}	
	
	
	boolean validate = false;
	List<String> validationErrors = new ArrayList<String>();
	
	@Override
	public boolean validateDetails(CustomerBean bean) throws MobileException 
	{
	if(!(validateName(bean.getCname()) ))
	{
		validationErrors.add("\n Employee Name Should Be In Alphabets and minimum 4 characters long and max 15 characters long! \n");
	}
	
	if(!(validatePhone(bean.getPhoneno())))
	{
		validationErrors.add("\nContact number should be exact 10 digits! \n");
	}

	if(!(validateEmail(bean.getMailid())))
	{
		validationErrors.add("\n Not a valid email id \n" );
	}
	
	if(!validationErrors.isEmpty())
	{
		throw new MobileException(validationErrors +"");
	}
	else
	{
		validate = true;
	}
	return validate;
}
}
